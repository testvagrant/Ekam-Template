package ekam.example.mobile;

import com.testvagrant.ekam.testBases.testng.MobileTest;
import org.testng.annotations.Test;

@Test(groups = "mobile")
public class MobileExampleTest extends MobileTest {
}
