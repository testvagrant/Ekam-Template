package ekam.example.api;

import com.testvagrant.ekam.commons.LayoutInitiator;
import com.testvagrant.ekam.testBases.testng.APITest;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

@Test(groups = "api")
public class APIExampleTest extends APITest {

}
