package ekam.example.api;

import com.testvagrant.ekam.testBases.testng.APITest;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

@Test(groups = "api")
public class APIExampleTest extends APITest {}
