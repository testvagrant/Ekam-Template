package ekam.example.web;

import com.testvagrant.ekam.testBases.testng.WebTest;
import org.testng.annotations.Test;

@Test(groups = "web")
public class WebExampleTest extends WebTest {
}
